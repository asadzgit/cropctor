# Agri-Pal
Agri-Pal is the simplest solution to aid a farmer in Agriculture - Crop and Poultry Farming. Agri-Pal is a simple Plug n Play device ensuring Disease Detection and Animal Breach Detection.
## Features:
1. Monitor and evaluate the plant's physical environment <br/>
2. Detects Plant and Poultry Diseases and intimate the user via Mobile App. <br/>
3. App and Chatbot is introduced to guide the user which will attract Youth more into Agriculture. As a result more involvement of Youth in Agriculture.
The Chat Bot is programmed in a diversity of languages to ensure that the user is able to easily clarify all their doubts and to know what they have to do in particular situations easily.<br/>
4. Detects animal attacks like cats/monkeys/rodents and take the required action to chase them away from the field without affecting them psychologically<br/>
5. Agri-Pal is designed to increase productivity and Decrease the losses as much as possible.<br/>
6. Children in towns and cities do not get the chance to understand Agriculture in a practical way and there is nobody to guide them in it and as a result, they lose their interest. Agri-Pal will serve as a personnel companion and help them nurture their passion for agriculture<br/>
7. Gardners and Kitchen Gardners can make the best use of the Device to monitor and detect diseases in their gardens, helping them in nurturing their interest it.<br/>

![image](https://user-images.githubusercontent.com/82273183/133211133-7684b8a5-0671-4a26-8b05-e0bf029bbe6d.png)

## App wireframe:
![image](https://user-images.githubusercontent.com/82273183/133208607-100eb99e-93be-46d5-a58a-564477a9188d.png)
## Chatbot:
![image](https://user-images.githubusercontent.com/82273183/133210894-e84d31fa-8bff-4f04-868a-c95c7931a130.png)
